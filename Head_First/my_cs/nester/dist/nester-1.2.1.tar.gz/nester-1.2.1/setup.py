from distutils.core import setup


setup(
	name = 'nester',
	version = '1.2.1',
	py_modules = ['nester'],
	author = 'SunTao',
	author_email = 'aoxilis@gmail.com',
	url = 'solen.co',
	descriptioin = 'print out the list data as formatted text in the file.'
)
